using UnityEngine.SceneManagement;
using UnityEngine;

public class MENU_CUSTUMIZE : MonoBehaviour
{
   public void Back()
    {
        SceneManager.LoadScene("Game");
    }
}
