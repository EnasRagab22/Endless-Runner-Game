using UnityEngine.SceneManagement;
using UnityEngine;

public class CUSTUMIZE_MENU : MonoBehaviour
{
   public void Custumize()
    {
        SceneManager.LoadScene("CUSTUMIZE");
    }
}
